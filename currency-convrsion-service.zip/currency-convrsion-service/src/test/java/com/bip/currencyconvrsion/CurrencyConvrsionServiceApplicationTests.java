package com.bip.currencyconvrsion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurrencyConvrsionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
